﻿using System.Web.UI;

namespace Assignment1_COMP_229_300808436.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}